from odoo import models, fields

class PowerBiModelLine(models.Model):
    _name = "power.bi.model.line"
    _description = "Power BI Field Mapping"

    power_bi_model_id = fields.Many2one('power.bi.model', string="Power BI Model")
    display_name = fields.Char(string="Display Name")
    model = fields.Char(string="Model Name", related='power_bi_model_id.model_name')
    field_name = fields.Char(string="Field")
