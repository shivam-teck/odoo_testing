from odoo import models, fields, api
from odoo.exceptions import ValidationError
import re
import ast

class PowerBiModel(models.Model):
    _name = "power.bi.model"
    _description = "Power BI Data Model"
    _rec_name = "name"

    name = fields.Char(string="Field Name", required=True)
    model_id = fields.Many2one('ir.model', string='Model', help="Select the model")
    filter = fields.Char(string="Filter", help="Add domain filter")
    model_name = fields.Char(related='model_id.model', string="Model Name", store=True)
    field_mapping_ids = fields.One2many(
        'power.bi.model.line', 'power_bi_model_id', string="Field Mapping"
    )

    _sql_constraints = [
        ('unique_field_name', 'unique(name)', 'Field Name must be unique!')
    ]

    @api.constrains('name')
    def _check_name(self):
        for rec in self:
            if rec.name and not re.match(r'^[A-Za-z_]+$', rec.name):
                raise ValidationError(
                    "Field Name must contain only letters and underscores (_)."
                )

    def action_open_data(self):
        self.ensure_one()
        if not self.model_id:
            raise ValidationError("Please select a Model first!")
        if not self.field_mapping_ids:
            raise ValidationError("Please add at least one field mapping.")

        url = f"/power_bi/view/{self.id}"
        return {
            'type': 'ir.actions.act_url',
            'url': url,
            'target': 'new',  # open in new tab
        }
