odoo.define('power_bi.power_bi_js', function(require){
    "use strict";
    var $ = require('jquery');
    $(document).ready(function() {
        var modelName = "Sample Model";
        var table = $('#power_bi_table').DataTable({
            pageLength: 100,
            lengthChange: false,
            searching: true,
            ordering: true,
            paging: true,
            scrollX: true,
            responsive: true,
            fixedHeader: true,
            dom: 'Bfrtip',
            buttons: [{
                extend: 'excelHtml5',
                title: modelName,
                exportOptions: {
                    columns: function(idx) {
                        if(idx === 0) return true;
                        return $('#column_checkbox_list input[data-index="'+idx+'"]').prop('checked');
                    }
                },
                text: '',
                className: 'dt-button-excel-hidden'
            }],
            fixedColumns: { leftColumns: 1 }
        });

        $('#power_bi_table_filter').hide();

        $('#table_search_input').on('keyup', function () {
            table.search(this.value).draw();
        });

        $('#excel_export_btn').on('click', function() {
            var btn = $(this);
            var icon = btn.find('.excel-icon');
            var text = btn.find('.excel-text');
            icon.text('⏳');
            text.text('Preparing...');
            setTimeout(function() {
                table.button(0).trigger();
                icon.text('✅');
                text.text('Downloaded!');
                setTimeout(function() {
                    icon.text('📊');
                    text.text('Export to Excel');
                }, 1500);
            }, 500);
        });

        function setInitialVisibility() {
            var width = $(window).width();
            table.columns().every(function(index) {
                if(index === 0) return this.visible(true);
                if(width > 1400) this.visible(true);
                else if(width > 1000) this.visible(index <= 6);
                else this.visible(false);
            });
        }

        function buildColumnList() {
            $('#column_checkbox_list').empty();
            var visibleSection = $('<div class="column-section"><h5>Visible</h5></div>');
            var hiddenSection = $('<div class="column-section"><h5>Hidden</h5></div>');

            table.columns().every(function(index) {
                if(index === 0) return;
                var colName = $(this.header()).text();
                var isVisible = this.visible();
                var checkbox = $('<label class="column-item"><input type="checkbox" data-index="'+index+'" '+(isVisible?'checked':'')+'> '+colName+'</label>');

                checkbox.find('input').on('change', function() {
                    var col = table.column(index);
                    col.visible(this.checked);
                    checkbox.addClass('highlight');
                    checkbox.addClass(this.checked ? '' : 'hide');
                    setTimeout(function() {
                        if(!checkbox.find('input').prop('checked')) checkbox.appendTo(hiddenSection).removeClass('hide highlight');
                        else checkbox.appendTo(visibleSection).removeClass('highlight hide');
                    }, 300);
                });

                if(isVisible) visibleSection.append(checkbox);
                else hiddenSection.append(checkbox);
            });

            $('#column_checkbox_list').append(visibleSection, hiddenSection);
        }

        setInitialVisibility();
        buildColumnList();

        $(window).on('resize', function() {
            setInitialVisibility();
            buildColumnList();
        });

        $('#select_all_cols').on('click', function() {
            $('#column_checkbox_list input[type="checkbox"]').each(function() {
                $(this).prop('checked', true).trigger('change');
            });
        });
        $('#deselect_all_cols').on('click', function() {
            $('#column_checkbox_list input[type="checkbox"]').each(function() {
                $(this).prop('checked', false).trigger('change');
            });
        });

        $('#column_toggle_btn').on('click', function() {
            var popup = $('#column_toggle_popup');
            popup.toggleClass('show');
            if(popup.hasClass('show')) popup.stop(true,true).slideDown(300);
            else popup.stop(true,true).slideUp(300);
        });
        $(document).on('click', function(e) {
            if (!$(e.target).closest('#column_toggle_popup, #column_toggle_btn').length) {
                $('#column_toggle_popup').removeClass('show').stop(true,true).slideUp(300);
            }
        });

        const rowPopup = $('#rowHoverPopup');
        $('#power_bi_table tbody').on('mouseenter', 'td', function () {
            var cellValue = $(this).text().trim();
            if (!cellValue) return;
            var columnName = $(this).closest('table').find('th').eq($(this).index()).text();
            var popupContent = '<div class="popup-inner"><div><strong>' + columnName + ':</strong> ' + cellValue + '</div></div>';
            var cellOffset = $(this).offset();
            var cellHeight = $(this).outerHeight();
            rowPopup.stop(true,true).html(popupContent).css({
                display: 'block',
                position: 'absolute',
                top: cellOffset.top + cellHeight + 5,
                left: cellOffset.left,
                transform: 'scale(0.95)',
                opacity: 0
            }).animate({opacity:1}, {
                duration: 200,
                step: function(now, fx) {
                    if(fx.prop==="opacity") $(this).css("transform","scale("+(0.95+now*0.05)+")");
                }
            });
        });
        $('#power_bi_table tbody').on('mouseleave', 'td', function () {
            rowPopup.stop(true,true).fadeOut(150);
        });
    });
});
