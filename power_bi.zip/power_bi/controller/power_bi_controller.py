from odoo import http
from odoo.http import request
import ast
import operator

class PowerBiController(http.Controller):

    @http.route('/power_bi/view/<int:model_id>', type='http', auth='user', website=True)
    def view_data(self, model_id, **kwargs):
        model_rec = request.env['power.bi.model'].browse(model_id)
        if not model_rec.exists():
            return "Model not found!"

        # Prepare domain
        domain = []
        if model_rec.filter:
            try:
                domain = ast.literal_eval(model_rec.filter)
            except Exception:
                return "Invalid filter domain!"

        # Fetch records
        Model = request.env[model_rec.model_id.model]
        records = Model.search(domain, limit=1000)

        # Helper to evaluate nested field expressions like product_id.name or partner_id.country_id.name
        def get_nested_value(record, field_expr):
            try:
                attrs = field_expr.split('.')
                value = record
                for attr in attrs:
                    value = getattr(value, attr, False)
                    if value is False or value is None:
                        return ''
                # For one2many/many2many, return joined values
                if hasattr(value, '__iter__') and not isinstance(value, str):
                    return ', '.join([str(v) for v in value])
                return str(value)
            except Exception:
                return ''

        # Prepare table data
        table_data = []
        for rec in records:
            row = {fm.display_name: get_nested_value(rec, fm.field_name) for fm in model_rec.field_mapping_ids}
            table_data.append(row)

        columns = [fm.display_name for fm in model_rec.field_mapping_ids]

        return request.render('power_bi.power_bi_dynamic_table', {
            'model_name': model_rec.name,
            'columns': columns,
            'table_data': table_data,
        })
